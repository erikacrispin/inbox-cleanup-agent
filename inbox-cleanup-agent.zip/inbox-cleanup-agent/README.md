# Inbox Cleanup Agent

A zero-cost, self-hosted Gmail agent that runs twice a day and keeps your inbox clean — without deleting a single email.

Built with Google Apps Script. No servers, no API keys, no dependencies.

## What it does

Every 12 hours, the agent scans your inbox and sorts bulk mail into color-coded labels, then archives it out of your inbox:

| Label | Catches |
|---|---|
| `AI-Cleanup/Promo` | Sales, marketing, offers |
| `AI-Cleanup/Newsletter` | Digests, subscriptions, roundups |
| `AI-Cleanup/Notification` | Automated alerts, job alerts, event blasts |

Everything stays searchable and recoverable — archived, never deleted.

## Safety rules

The agent is deliberately conservative:

- **Never deletes.** Label + archive only.
- **Never touches starred emails** or threads you've replied to.
- **Never touches protected senders** (banks, security alerts, appointments — configurable).
- **When uncertain, it does nothing.** Ambiguous emails stay in your inbox.

Bulk mail is detected through explicit sender rules, subject keywords, and the
`List-Unsubscribe` header — a signal that an email is a mailing-list blast
rather than a personal message.

## Setup (~3 minutes)

1. Go to [script.google.com](https://script.google.com) → **New project**
2. Replace the placeholder with the contents of `Code.gs` and save
3. Select `runInboxCleanup` in the toolbar dropdown → **Run** once → approve the
   Gmail authorization (Google will warn the app is unverified — that's expected
   for personal scripts; click *Advanced → Go to project → Allow*)
4. Open **Triggers** (clock icon) → **Add Trigger** →
   `runInboxCleanup` · Time-driven · Hour timer · **Every 12 hours** → Save

Done. It now runs itself twice a day.

## Tuning

All configuration lives at the top of `Code.gs`:

- `PROTECTED_SENDERS` — domains that must never be archived
- `RULES` — sender domains and subject keywords per category
- `MAX_THREADS_PER_RUN` — batch size per run

When something gets archived that shouldn't be: drag it back to your inbox and
add its sender to `PROTECTED_SENDERS`. When a new bulk sender floods you: add
its domain to `RULES`.

## License

MIT
